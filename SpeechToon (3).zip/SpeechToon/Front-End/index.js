const form = document.getElementById('loginForm2')
form.addEventListener('submit', async (e) => {
    e.preventDefault()

    window.location.replace("http://127.0.0.1:5500/Front-End/login.html");
})